from sklearn import datasets
iris = datasets.load_iris()

Examples = {
    'Iris': iris,
}