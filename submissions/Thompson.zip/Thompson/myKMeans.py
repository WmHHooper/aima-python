from sklearn import datasets
from sklearn.cluster import KMeans
iris = datasets.load_iris()

Examples = {
    'IrisDefault': {
        'frame': iris,
    },
}